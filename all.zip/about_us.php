<?php
    include('yoo.php')
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="all2.css">
    <style>
        h2{
            color:white;
        }
    </style>
</head>
<body>
    <div class="main">
        <div class="main-inner">
            <h1>About Us</h1>
            <h2>Welcome to Heart Warmer — where connections are made and the journey to your next chapter begins.</h2>
            <h2>At Heart Warmer, we believe in the power of genuine connections. Our mission is simple: to bring people together, creating an environment where love, friendship, and meaningful relationships can thrive. Whether you're looking for love or simply new connections, Heart Warmer is the place to meet like-minded individuals who share your passions and values.
                
                We know how important it is to find someone who truly connects with you. That’s why we’ve built a space where authenticity and warmth are at the forefront, and where every new interaction feels like the start of something special.</h2>
            <h1>Your next chapter starts here.</h1>
            <h2>Join us today and start creating meaningful connections that last a lifetime.</h2>
        </div>
    </div>
</body>
</html>
