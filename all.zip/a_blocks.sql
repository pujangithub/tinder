CREATE TABLE blocks (
    block_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,       
    blocked_user_id INT, 
    FOREIGN KEY (user_id) REFERENCES account(id) ON DELETE CASCADE,
    FOREIGN KEY (blocked_user_id) REFERENCES account(id) ON DELETE CASCADE
);
