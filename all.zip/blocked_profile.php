<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit();
}

$userId = $_SESSION['user_id'];
include("connect.php");

// Reset index if needed
if (!isset($_SESSION['blocked_profile_index']) || isset($_GET['reset'])) {
    $_SESSION['blocked_profile_index'] = 0;
}

// Get blocked profiles
$blockedProfilesQuery = mysqli_query($con, "SELECT blocked_user_id FROM blocks WHERE user_id = $userId");
$blockedUserIds = mysqli_fetch_all($blockedProfilesQuery, MYSQLI_ASSOC);

// Prepare an array of blocked user IDs
$blockedUserIdsArray = array_column($blockedUserIds, 'blocked_user_id');

if (!empty($blockedUserIdsArray)) {
    // Get profiles of blocked users
    $profilesQuery = mysqli_query($con, "SELECT * FROM about_you WHERE user_id IN (" . implode(',', $blockedUserIdsArray) . ")");
    $profiles = mysqli_fetch_all($profilesQuery, MYSQLI_ASSOC);
} else {
    $profiles = []; // Set profiles to an empty array if no blocked user IDs
}

// Handle profile index
$profileIndex = $_SESSION['blocked_profile_index'] ?? 0;
if ($profileIndex >= count($profiles)) {
    $profileIndex = 0;
    $_SESSION['blocked_profile_index'] = 0;
}

$currentProfile = $profiles[$profileIndex] ?? null;

// Handle navigation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['next'])) {
        $profileIndex = ($profileIndex + 1) % count($profiles);
    } elseif (isset($_POST['previous'])) {
        $profileIndex = ($profileIndex - 1 + count($profiles)) % count($profiles);
    }
    $_SESSION['blocked_profile_index'] = $profileIndex;
    header("Location: blocked_profile.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blocked Profiles</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="all.css">
    <link rel="stylesheet" href="all1.css">
</head>
<body>
<video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>

<div class="nav">
    <a href="index1.php"><img src="logoo.png" alt="Logo"></a>
    <a href="about_us.php" class="block1">About us</a>
    <a href="contact_us.php" class="block1">Contact us</a>
    <a href="aprofile.php?user_id=<?= $userId ?>" class="block1">Profile</a>
</div>

<div class="main">
<?php if ($currentProfile): ?> 
    <div class="image-container">
            <div class="image-card">
                <img src="images/<?= $currentProfile['profile_photo'] ?>" alt="Profile">
                <div class="three-dots">
                    &#x22EE;    
                </div>
                <div class="delete-update-options">
                    <a href="block.php?block_user_id=<?= $currentProfile['user_id'] ?>">Unblock</a>
                </div>
            </div>  
    </div>
    <div class="pageTitle">
    <a href="blocked_profile.php"><h1>Blocked profile</h1></a>
    </div>
    <div class="details">
        <h2>Name: <?= $currentProfile['full_name'] ?></h2>
        <h2>Age: <?php 
            $dob = new DateTime($currentProfile['dob']);
            echo $dob->diff(new DateTime())->y;
        ?></h2>
        <h2>Location: <?= $currentProfile['location'] ?></h2>
        <h2>Looking for: <?= $currentProfile['looking_for'] ?></h2>
        <a href="more_details.php?user_id=<?= $currentProfile['user_id'] ?>"><h4>More details</h4></a>
    </div>

    <div class="details2">
        <form method="post">
            <button type="submit" name="next">Next</button>
        </form>
    </div>

    <div class="details3">
        <form method="post">
            <button type="submit" name="previous">Previous</button>
        </form>
    </div>

    <div class="details4">
    <a href="liked_profile.php"><h1>Profiles you liked 💖</h1></a>
    <a href="matched_profile.php"><h1>Matched profiles 💕</h1></a>
    </div>
<?php else: ?>
    <h2>No blocked profiles to show</h2>
<?php endif; ?>
</div>

<script>
      document.addEventListener("DOMContentLoaded", function() {
        const dots = document.querySelector(".three-dots");
        const options = document.querySelector(".delete-update-options");

        dots.addEventListener("click", function() {
            options.classList.toggle("show-options"); // Toggle visibility of options
        });
    });
</script>
</body>
</html>