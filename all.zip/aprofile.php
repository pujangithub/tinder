<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="all.css">
    <link rel="stylesheet" href="all1.css">
</head>
<body>
    <video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>

    <div class="nav">
        <a href="index1.php"><img src="logoo.png" alt="Logo"></a>
        <a href="about_us.php" class="block1">About us</a>
        <a href="contact_us.php" class="block1">Contact us</a>
        <div class="login1">
            <a href="logout.php" style="color: black; font-size: 20px; text-decoration: none;">Log out</a>
        </div>
    </div>

    <?php
        include("connect.php");
        session_start();
        if (!isset($_SESSION['user_id'])) {
            header("Location: login.php"); 
            exit();
        }
        $id = $_SESSION['user_id'];
        $q = "SELECT * FROM about_you WHERE user_id = $id";
        $result = mysqli_query($con, $q);
        $row = mysqli_fetch_array($result, MYSQLI_NUM);
    ?>

    <div class="main">
        <div class="image-container">
            <div class="image-card">
                <img src="images/<?php echo $row[23]; ?>" alt="Profile Picture">
                <div class="three-dots">
                    &#x22EE; <!-- Ellipsis character -->
                </div>
                <div class="delete-update-options">
                    <a href="deleteprofile.php">Delete account</a>
                    <a href="edit_profile_form.php">Edit account</a>
                </div>
            </div>
        </div>
        <div class="pageTitle">
    <a href="aprofile.php"><h1>Your profile </h1></a>
    </div>

        <div class="details">
            <h2>Name: <?php echo $row[1]; ?></h2>   
            <?php
                $dob = $row[2]; 
                $dobObject = new DateTime($dob);
                $today = new DateTime(); 
                $age = $today->diff($dobObject)->y; 
            ?>

            <h2>Age:<?php echo $age;?></h2>
            <h2>Phone no: <?php echo $row[5]; ?></h2>
            <h2>Email: <h3><?php echo $row[4]; ?></h3></h2>
            <a href="more_details1.php?user_id=<?=$id ?>"><h4>More details</h4></a>
        </div>

        <div class="details4">
            <a href="liked_profile.php"><h1>Profiles you liked 💖</h1></a>
            <a href="matched_profile.php"><h1>Matched profiles 💕</h1></a>
            <a href="blocked_profile.php"><h1>Profiles you blocked 🚫</h1></a>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const dots = document.querySelector(".three-dots");
            const options = document.querySelector(".delete-update-options");

            dots.addEventListener("click", function() {
                options.classList.toggle("show-options"); // Toggle visibility of options
            });
        });
    </script>

</body>
</html>
