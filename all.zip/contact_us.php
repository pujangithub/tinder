<?php
    include('yoo.php')
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="all2.css">
</head>
<body>
    <div class="main">
        <div class="main-inner">
            <h1>Contact Us</h1>
            <h3>We’re here to help you! Whether you have questions, feedback, or need assistance, don’t hesitate to reach out to us. Our team is dedicated to ensuring your experience with Heart Warmer is as seamless and enjoyable as possible.</h3>
            <h1>Here’s how you can contact us:</h1>
            <h2>Email:</h2>
            <h3>For general inquiries or support, email us at <span style=" color: #ff6600;">lauredairock124@gmail.com</span>. We're here to assist you!</h3>
            <h2>Phone:</h2>
            <h3>You can reach us at 9767410477 Monday to Friday, from 9 AM to 6 PM.</h3>
            <h2>Social Media:</h2>
            <h3><a href="">Facebook</a></h3>
            <h3><a href="">Instagram</a></h3>
            <h2>Feedback:</h2>
            <h3>We value your feedback! Let us know how we’re doing and what we can improve to make your experience even better. Your connection is important to us, and we’re committed to providing the support you need.</h3>
        </div>
    </div>
</body>
</html>
