<?php
session_start();
include("connect.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];
$blockedUserId = filter_input(INPUT_GET, 'block_user_id', FILTER_VALIDATE_INT);

if (!$blockedUserId) {
    http_response_code(400);
    die('Invalid user ID');
}

// Check if the user has already blocked the other user
$checkStmt = $con->prepare("SELECT block_id FROM blocks WHERE user_id = ? AND blocked_user_id = ?");
$checkStmt->bind_param('ii', $userId, $blockedUserId);
$checkStmt->execute();
$exists = $checkStmt->get_result()->num_rows > 0;
$checkStmt->close();

// If the user has already blocked, unblock them (delete record)
if ($exists) {
    $stmt = $con->prepare("DELETE FROM blocks WHERE user_id = ? AND blocked_user_id = ?");
    $action = 'unblocked';
} else {
    // If not blocked, block the user (insert record)
    $stmt = $con->prepare("INSERT INTO blocks (user_id, blocked_user_id) VALUES (?, ?)");
    $action = 'blocked';
}

$stmt->bind_param('ii', $userId, $blockedUserId);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    if($action=='blocked'){
    echo "<script>
    alert('Account " . ucfirst($action) . "!');
    window.location.href='index1.php'; 
    </script>";
    }
    else{
        echo "<script>
    alert('Account " . ucfirst($action) . "!');
    window.location.href='blocked_profile.php'; 
    </script>";
    }
} else {
    http_response_code(500);
    echo 'Database error';
}

$stmt->close();
$con->close();
?>
