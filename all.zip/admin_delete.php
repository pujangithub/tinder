<?php
include('connect.php');
session_start();

// Ensure only admin can delete users
if (!isset($_SESSION['admin_id'])) { // Ensure only admin can delete users
    echo "<script>alert('Unauthorized access!'); window.location.href='admin.php';</script>";
    exit();
}

// Validate and get user ID
if (isset($_GET['id'])) {
    $userId = intval($_GET['id']); // Convert to integer for safety

    // Delete user from `about_you` table
    $delete_aboutyou = mysqli_query($con, "DELETE FROM about_you WHERE about_id = $userId");

    if ($delete_aboutyou) {
        // Also delete from `account` table
        $delete_account = mysqli_query($con, "DELETE FROM account WHERE id = $userId");

        if ($delete_account) {
            // Delete likes associated with user
            $delete_like = mysqli_query($con, "DELETE FROM likes WHERE user_id = $userId");

            if ($delete_like) {
                echo "<script>
                        alert('User deleted successfully!');
                        window.location.href='admin.php';
                      </script>";
            } else {
                echo "<script>alert('Could not delete user likes!'); window.location.href='admin.php';</script>";
            }
        } else {
            echo "<script>alert('Could not delete user account!'); window.location.href='admin.php';</script>";
        }
    } else {
        echo "<script>alert('Could not delete user details!'); window.location.href='admin.php';</script>";
    }
} else {
    echo "<script>alert('Invalid user ID!'); window.location.href='admin.php';</script>";
}
?>
