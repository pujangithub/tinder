
    const modal = document.getElementById("imageModal");
    const profileImage = document.getElementById("profileImage");
    const enlargedImage = document.getElementById("enlargedImage");
    const closeModal = document.querySelector(".close-modal");
    
    profileImage.addEventListener("click", function() {
        modal.style.display = "block";
        enlargedImage.src = this.src;
    });
    
    closeModal.addEventListener("click", function() {
        modal.style.display = "none";
    });
    
    window.addEventListener("click", function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    });