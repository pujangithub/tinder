<?php
include('connect.php');
session_start();
// Ensure only admin can access the page
if (!isset($_SESSION['admin_id'])) {
    echo "<script>alert('Unauthorized access!'); window.location.href='login.php';</script>";
    exit();
}

// Fetch users from `about_you` table
$result = mysqli_query($con, "SELECT about_id, full_name, location, email, phone FROM about_you");
$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page - All Users</title>
    <link rel="stylesheet" href="all.css">
    <style>
        .admin_container {
            width: 100%;
            display: flex;
            justify-content: center;
            margin-top: 80px; 
            flex-direction: column;
            align-items: center;
        }

        .admin_view {
            width: 80%;
            text-align: center;
            background: rgba(0, 0, 0, 0.6);
            align-items: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            overflow: hidden;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            text-align: left;
            color: white;
        }

        th {
            background: rgba(0, 0, 0, 0.7);
        }

        tr:nth-child(even) {
            background: rgba(255, 255, 255, 0.2);
        }

        .delete-btn {
            background-color: white;
            color: red;
            border: 1px solid red;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s;
        }

        .delete-btn:hover {
            background-color: red;
            color: white;
        }

        .view-btn {
            background-color: white;
            color: blue;
            border: 1px solid blue;
            padding: 8px 12px;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
            transition: 0.3s;
        }

        .view-btn:hover {
            background-color: blue;
            color: white;
        }

    </style>
</head>
<body>

    <video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>

    <div class="nav">
        <a href="admin.php"><img src="logoo.png" alt=""></a>   
        <div class="login1">
            <a href="logout.php" style="color: black; font-size: 20px; text-decoration: none;">Log out</a>
        </div>              
    </div>

    <div class="admin_container">
        <h1>All Users</h1>
        <div class="admin_view">
            <table>
                <tr>
                    <th>Full Name</th>
                    <th>Location</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th colspan="2">Action</th>
                </tr>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td><?php echo $row['full_name']; ?></td>
                        <td><?php echo $row['location']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td><button class="delete-btn" onclick="admin_delete_account(<?php echo $row['about_id']; ?>)">Delete</button></td>
                        <td><button class="view-btn" onclick="view_account(<?php echo $row['about_id']; ?>)">View</button></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>

    <script>
        function admin_delete_account(userId) {
            if (confirm("Are you sure you want to delete this user?")) {
                window.location.href = "admin_delete.php?id=" + userId;
            }
        }
        function view_account(userId) {
                window.location.href = "admin_view.php?id=" + userId;
        }
    </script>

</body>
</html>
