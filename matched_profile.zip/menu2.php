<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit();
}

$userId = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dating App</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="all.css">
    <style>
       * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100vw;
            height: 100vh;
            overflow: hidden;
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .container{
            display: flex;
            align-items: center;
            position: absolute;
            justify-content: center;
            width: 100%;
            height: 30vh;
            z-index: 1;
            top: 25vh;
            font-family: 'Nunito', sans-serif;
        }
         
        .text {
            z-index: 1; 
            font-size: 80px;
            color: white;
            font-weight: bold;
            text-shadow: 5px 5px 20px rgba(0, 0, 0, 0.8); 
            opacity: 0;
            animation: fadeInText 2s forwards; 
        }

        .create-account {
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            z-index: 1;
            height: 10vh;
            top: 53vh;
            opacity: 0;
            animation: fadeInLink 2s 1s forwards; 
        }
        
    

        .link{
            font-size: 30px;
            text-decoration: none;
            color: white;
            font-weight: bold;
            background-color:  rgb(132, 22, 215);
            width: 280px;
            height: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 30px;
            
        }

        
        @keyframes fadeInText {
            0% {
                opacity: 0;
                transform: translateY(-50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

       
        @keyframes fadeInLink {
            0% {
                opacity: 0;
                transform: translateY(50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .login1{
            display: flex;
            justify-content: center;
            right: 30px;
            background-color: white ;
            width: 150px;
            align-items: center;
            border-radius: 30px;
            height: 40px;
            
        }
        .block1{
            font-weight: bold;
            font-size: 40px;
            text-decoration: none;
            color: white;
            text-shadow: 5px 5px 20px rgba(0, 0, 0, 0.8); 
        }

    </style>
</head>
<body>
<video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>
<div class="container">
        <p class="text">Your Next Chapter Starts Here</p>
    </div>
<div class="nav">
    <a href="index1.php"><img src="logoo.png" alt="Logo"></a>
    <a href="about_us.php" class="block1">About us</a>
    <a href="contact_us.php" class="block1">Contact us</a>
    <a href="aprofile.php?user_id=<?= $userId ?>" class="block1">Profile</a>
</div>
<div class="create-account">
        <a href="index1.php" class="link">Start</a>
        
    </div>