    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Home Page</title>
        <link rel="stylesheet" href="all.css">
    </head>
    <body>

        <video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>
            <?php
            session_start();
            ?>
            <div class="nav">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="index1.php"><img src="logoo.png" alt=""></a>
                <?php else: ?>
                    <a href="menu.html"><img src="logoo.png" alt=""></a>
                <?php endif; ?>
                
                <a href="about_us.php" class="block1">About us</a>
                <a href="contact_us.php" class="block1">Contact us</a>
            </div>

    </body>
    </html>

