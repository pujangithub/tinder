<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit();
}

$userId = $_SESSION['user_id'];
include("connect.php");

// Reset index if needed
if (!isset($_SESSION['liked_profile_index']) || isset($_GET['reset'])) {
    $_SESSION['liked_profile_index'] = 0;
}

// Get liked profiles
$likedProfilesQuery = mysqli_query($con, 
    "SELECT a.* FROM about_you a 
    JOIN likes l ON a.user_id = l.liked_user_id 
    WHERE l.user_id = $userId
    AND a.user_id NOT IN (SELECT blocked_user_id FROM blocks WHERE user_id = $userId)");
    
$profiles = mysqli_fetch_all($likedProfilesQuery, MYSQLI_ASSOC);

// Handle profile index
$profileIndex = $_SESSION['liked_profile_index'] ?? 0;
if ($profileIndex >= count($profiles)) {
    $profileIndex = 0;
    $_SESSION['liked_profile_index'] = 0;
}

$currentProfile = $profiles[$profileIndex] ?? null;

// Handle navigation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['next'])) {
        $profileIndex = ($profileIndex + 1) % count($profiles);
    } elseif (isset($_POST['previous'])) {
        $profileIndex = ($profileIndex - 1 + count($profiles)) % count($profiles);
    }
    $_SESSION['liked_profile_index'] = $profileIndex;
    header("Location: liked_profile.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liked Profiles</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="all.css">
    <link rel="stylesheet" href="all1.css">
    <style>
    .heart {
        position: absolute;
        bottom: 63px; 
        right: 15px; 
        cursor: pointer;
    }
    </style>
</head>
<body>
<video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>

<div class="nav">
    <a href="index1.php"><img src="logoo.png" alt="Logo"></a>
    <a href="about_us.php" class="block1">About us</a>
    <a href="contact_us.php" class="block1">Contact us</a>
    <a href="aprofile.php?user_id=<?= $userId ?>" class="block1">Profile</a>
</div>

<div class="main">
<?php if ($currentProfile): ?> 
    <div class="image-container">
        <div class="image-card">
            <img src="images/<?= $currentProfile['profile_photo'] ?>" alt="Profile">
        </div>
    </div>
    <div class="pageTitle">
    <a href="liked_profile.php"><h1>Profiles you liked </h1></a>
    </div>
    
    <div class="details">
        <h2>Name: <?= $currentProfile['full_name'] ?></h2>
        <h2>Age: <?php 
            $dob = new DateTime($currentProfile['dob']);
            echo $dob->diff(new DateTime())->y;
        ?></h2>
        <h2>Location: <?= $currentProfile['location'] ?></h2>
        <h2>Looking for: <?= $currentProfile['looking_for'] ?></h2>
        <a href="more_details.php?user_id=<?= $currentProfile['user_id'] ?>"><h4>More details</h4></a>
    </div>

    <div class="details2">
        <form method="post">
            <button type="submit" name="next">Next</button>
        </form>
    </div>

    <div class="details3">
        <form method="post">
            <button type="submit" name="previous">Previous</button>
        </form>
    </div>

    <button class="heart clicked" 
            type="button" 
            data-user-id="<?= $currentProfile['user_id'] ?>"></button>
    
    <div class="details4">
        <a href="matched_profile.php"><h1>Matched profiles 💕</h1></a>
        <a href="blocked_profile.php"><h1>Profiles you blocked 🚫</h1></a>
    </div>
<?php else: ?>
    <h2>No liked profiles to show</h2>
    <div class="details4">
    </div>
<?php endif; ?>
</div>

<script>
$(document).ready(function() {
    $('.heart').click(function() {
        const button = $(this);
        const userId = <?= $userId ?>;
        const likedUserId = button.data('user-id');

        $.ajax({
            url: 'like.php',
            type: 'POST',
            data: { liked_user_id: likedUserId },
            success: function(response) {
                response = response.trim();
                if (response === 'unliked') {
                    window.location.reload();
                } else {
                    alert('Error: ' + response);
                }
            },
            error: function(xhr) {
                alert('Error: ' + xhr.statusText);
            }
        });
    });
});
</script>
</body>
</html>