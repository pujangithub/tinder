<?php
session_start();
require 'connect.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    die('Unauthorized');
}

$userId = $_SESSION['user_id'];
$likedUserId = filter_input(INPUT_POST, 'liked_user_id', FILTER_VALIDATE_INT);

if (!$likedUserId) {
    http_response_code(400);
    die('Invalid user ID');
}

// Check existing like
$checkStmt = $con->prepare("SELECT id FROM likes WHERE user_id = ? AND liked_user_id = ?");
$checkStmt->bind_param('ii', $userId, $likedUserId);
$checkStmt->execute();
$exists = $checkStmt->get_result()->num_rows > 0;
$checkStmt->close();

// Toggle like status
if ($exists) {
    $stmt = $con->prepare("DELETE FROM likes WHERE user_id = ? AND liked_user_id = ?");
    $action = 'unliked';
} else {
    $stmt = $con->prepare("INSERT INTO likes (user_id, liked_user_id) VALUES (?, ?)");
    $action = 'liked';
}

$stmt->bind_param('ii', $userId, $likedUserId);
$stmt->execute();

if ($stmt->affected_rows > 0 || $action === 'unliked') {
    echo $action;
} else {
    http_response_code(500);
    echo 'Database error';
}

$stmt->close();
$con->close();
?>