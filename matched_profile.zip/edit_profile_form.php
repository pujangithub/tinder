<?php
   session_start();
   if (!isset($_SESSION['user_id'])) {
       header("Location: login.php"); 
       exit();
   }
   
   $userId = $_SESSION['user_id'];
   include("connect.php");
   $result = mysqli_query($con, "SELECT * FROM about_you WHERE user_id = $userId");
   $row = mysqli_fetch_array($result, MYSQLI_NUM);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Information Form</title>
    <link rel="stylesheet" href="form.css">
    <style>
        .form-container {
            border: 2px solid rgba(66, 165, 245, 0.8); 
        }
        h2 {
            color: #304cff; 
            background-color: white;
        }
        .form-section h3 {
            color: #725cff; 
            border-bottom: 1px solid #ddd;
        }
        label {
            color: #6a45ff; 
        }
        button:hover {
            background-color: #1565c0; 
        }
        .buttonn{
            display:flex;
            justify-content: center;
            flex-direction:row;
        }
    </style>
</head>

<body>

    <video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>
    <div class="nav">
        <a href="aprofile.php"><img src="logoo.png" alt=""></a>
        <a href="about_us.php" class="block1">About us</a>
        <a href="contact_us.php" class="block1">Contact us</a>
        <div class="login1">
            <a href="logout.php" style="color: black; font-size: 20px; text-decoration: none; text-shadow: 5px 5px 20px rgba(0, 0, 0, 0.8);">Log out</a>
        </div>
    </div>

    <div class="form-container">
        <h2>Edit User Profile Form</h2>
        <br>
        <form action="edit_profile.php" method="POST" enctype="multipart/form-data">

            <div class="form-section">
                <h3>Basic Profile Information</h3>
                <label for="fullName">Full Name:</label>
                <input type="text" id="fullName" name="fullName" required value="<?php echo $row[1]; ?>">

                <label for="dob">Age/Date of Birth:</label>
                <input type="date" id="dob" name="dob" value="<?php echo $row[2]; ?>" required>
            </div>

            <div class="form-section">
                <h3>Location</h3>
                <label for="location">Location:</label>
                <input type="text" id="location" name="location" required value="<?php echo $row[3]; ?>">
            </div>

            <div class="form-section">
                <h3>Contact Information</h3>
                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" required value="<?php echo $row[4]; ?>">

                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" required value="<?php echo $row[5]; ?>">

                <label for="facebook">Facebook ID <span class="optional">(Optional)</span>:</label>
                <input type="text" id="facebook" name="facebook" value="<?php echo $row[6]; ?>">

                <label for="instagram">Instagram ID <span class="optional">(Optional)</span>:</label>
                <input type="text" id="instagram" name="instagram" value="<?php echo $row[7]; ?>">
            </div>

            <div class="form-section">
                <h3>Personal Details for Profile</h3>
                <label for="bio">Bio/Description:</label>
                <textarea id="bio" name="bio" rows="4"><?php echo $row[8]; ?></textarea>

                <label for="hobbies">Hobbies/Interests:</label>
                <input type="text" id="hobbies" name="hobbies" value="<?php echo $row[9]; ?>">

                <label for="occupation">Occupation:</label>
                <input type="text" id="occupation" name="occupation" value="<?php echo $row[10]; ?>">

                <label for="education">Education:</label>
                <input type="text" id="education" name="education" value="<?php echo $row[11]; ?>">

                <label for="religion">Religion <span class="optional">(Optional)</span>:</label>
                <input type="text" id="religion" name="religion" value="<?php echo $row[12]; ?>">

                <label for="languages">Languages:</label>
                <input type="text" id="languages" name="languages" value="<?php echo $row[13]; ?>">
            </div>

            <div class="form-section">
            <h3>Photos</h3>
            <label for="profilePictures">Profile Pictures:</label>
            <input type="hidden" name="existing_photo" value="<?php echo base64_encode($row[23]); ?>">
            <input type="file" id="photo" name="photo" accept="image/*">
            </div>


            <div class="form-section">
                <h3>Lifestyle Preferences</h3>
                <label for="smoking">Smoking Habits:</label>
                <select id="smoking" name="smoking">
                    <option value="" disabled>Select an option</option>
                    <option value="yes" <?php if ($row[14] == "yes") echo "selected"; ?>>Yes</option>
                    <option value="no" <?php if ($row[14] == "no") echo "selected"; ?>>No</option>
                    <option value="occasionally" <?php if ($row[14] == "occasionally") echo "selected"; ?>>Occasionally</option>
                </select>
                <label for="drinking">Drinking Habits:</label>
                <select id="drinking" name="drinking">
                    <option value="" disabled>Select an option</option>
                    <option value="yes" <?php if ($row[15] == "yes") echo "selected"; ?>>Yes</option>
                    <option value="no" <?php if ($row[15] == "no") echo "selected"; ?>>No</option>
                    <option value="occasionally" <?php if ($row[15] == "occasionally") echo "selected"; ?>>Occasionally</option>
                </select>
                <label for="pets">Pets:</label>
                <input type="text" id="pets" name="pets" value="<?php echo $row[16]; ?>">
            </div>

            <div class="form-section">
                <h3>Relationship Goals</h3>
                <label for="lookingFor">Looking For:</label>
                <textarea id="lookingFor" name="lookingFor" rows="2"><?php echo $row[17]; ?></textarea>
            </div>

            <div class="form-section">
                <h3>Optional Fun Questions (Icebreakers)</h3>
                <label for="favorites">Favorite Music/Movies/Books:</label>
                <textarea id="favorites" name="favorites" rows="2"><?php echo $row[18]; ?></textarea>

                <label for="vacation">Dream Vacation Spot:</label>
                <input type="text" id="vacation" name="vacation" value="<?php echo $row[19]; ?>">

                <label for="truths">Two Truths and a Lie:</label>
                <textarea id="truths" name="truths" rows="3"><?php echo $row[20]; ?></textarea>
            </div>
            
            <div class="form-section">
            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="" disabled>Select your gender</option>
                <option value="male" <?php if ($row[21] == "male") echo "selected"; ?>>Male</option>
                <option value="female" <?php if ($row[21] == "female") echo "selected"; ?>>Female</option>
            </select>
            </div>  
            <div class="buttonn">
            <button type="submit">Update</button>
            <button type="button" class="cancel-button" onclick="window.location.href='aprofile.php';">Cancel</button>
            </div>
        </form>
    </div>

</body>

</html>
