<?php
session_start();

include 'connect.php';

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}


if (!isset($_POST['uname']) || !isset($_POST['pass'])) {
    header("Location: login.html");
    exit();
}

$username = $_POST['uname'];
$password = $_POST['pass'];
if($username=="admin"&&$password=="admin"){
    $_SESSION['admin_id'] = 'admin'; 
    echo "<script>
    alert('Admin login successful!');
    window.location.href='admin.php';
    </script>";
    exit();
}

$q = "SELECT id FROM account WHERE username ='$username'";
$result = mysqli_query($con, $q);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $_SESSION['user_id'] = $row['id'];
    header("Location: menu2.php");
    exit();
} else {
    echo "<script>
    alert('Login failed!');
    window.location.href='login.html';
    </script>";
    exit();
}

$con->close();
?>
