<?php
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php"); 
        exit();
    }

    // Check if the delete confirmation was received
    if (isset($_GET['confirm']) && $_GET['confirm'] == 'yes') {
        $userId = $_SESSION['user_id'];
        include("connect.php");

        // Delete data from about_you table
        $delete_aboutyou = mysqli_query($con, "DELETE FROM about_you WHERE user_id = $userId");
        if ($delete_aboutyou) {
            // Delete from account table
            $delete_account = mysqli_query($con, "DELETE FROM account WHERE id = $userId");
            if ($delete_account) {
                // Delete likes associated with the user
                $delete_like = mysqli_query($con, "DELETE FROM likes WHERE user_id = $userId");
                if ($delete_like) {
                    echo "<script>
                            alert('Account deleted successfully!');
                            window.location.href='login.html';
                          </script>";
                } else {
                    echo "Could not delete likes!";
                    header("Location: aprofile.php");
                }
            } else {
                echo "Could not delete account!";
                header("Location: aprofile.php");
            }
        } else {
            echo "Could not delete account details!";
            header("Location: aprofile.php");
        }
    } else {
        echo "<script>
                var confirmDelete = confirm('Are you sure you want to delete your account? This action is irreversible.');
                if (confirmDelete) {
                    window.location.href = 'delete_account.php?confirm=yes';
                } else {
                    window.location.href = 'aprofile.php';
                }
              </script>";
    }
?>
