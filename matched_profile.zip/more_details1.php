<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); 
    exit();
}

$userId = $_SESSION['user_id'];
$viewedUserId = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

include("connect.php");

// Get the profile details
$profileQuery = mysqli_query($con, "SELECT * FROM about_you WHERE user_id = $viewedUserId");
$profile = mysqli_fetch_assoc($profileQuery);

if (!$profile) {
    die("Profile not found");
}

// Calculate age
$dob = new DateTime($profile['dob']);
$age = $dob->diff(new DateTime())->y;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Details | Dating App</title>
    <link rel="stylesheet" href="all.css">
    <link rel="stylesheet" href="all1.css">
    <link rel="stylesheet" href="more_details.css">
    
</head>
<body>
<video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>

<div class="nav">
    <a href="index1.php"><img src="logoo.png" alt="Logo"></a>
    <a href="about_us.php" class="block1">About us</a>
    <a href="contact_us.php" class="block1">Contact us</a>
    <a href="aprofile.php?user_id=<?= $userId ?>" class="block1">Profile</a>
</div>

<!-- Image Modal -->
<div id="imageModal" class="image-modal">
    <span class="close-modal">&times;</span>
    <div class="modal-content">
        <img src="images/<?= $profile['profile_photo'] ?>" class="enlarged-image" id="enlargedImage">
    </div>
</div>

<div class="profile-container">
    <div class="profile-header">
        <div class="profile-image-container" id="profileImageContainer">
            <img src="images/<?= $profile['profile_photo'] ?>" alt="Profile Photo" class="profile-image" id="profileImage">
        </div>
        <div class="profile-info">
            <h1><?= $profile['full_name'] ?></h1>
            <h2><?= $age ?> years old</h2>
            <h2><?= $profile['location'] ?></h2>
            <h2>Looking for: <?= $profile['looking_for'] ?></h2>
        </div>
    </div>
    
    <div class="profile-section">
        <h2>About Me</h2>
        <p><?= nl2br($profile['bio']) ?></p>
    </div>
    
    <div class="profile-section">
        <h2>Personal Details</h2>
        <p><strong>Occupation:</strong> <?= $profile['occupation'] ?></p>
        <p><strong>Education:</strong> <?= $profile['education'] ?></p>
        <p><strong>Religion:</strong> <?= $profile['religion'] ?></p>
        <p><strong>Languages:</strong> <?= $profile['languages'] ?></p>
    </div>
    
    <div class="profile-section">
        <h2>Lifestyle</h2>
        <p><strong>Smoking:</strong> <?= ucfirst($profile['smoking']) ?></p>
        <p><strong>Drinking:</strong> <?= ucfirst($profile['drinking']) ?></p>
        <p><strong>Pets:</strong> <?= $profile['pets'] ?></p>
    </div>
    
    <div class="profile-section">
        <h2>Interests</h2>
        <p><strong>Hobbies:</strong> <?= nl2br($profile['hobbies']) ?></p>
        <p><strong>Favorites:</strong> <?= nl2br($profile['favorites']) ?></p>
        <p><strong>Dream Vacation:</strong> <?= nl2br($profile['vacation']) ?></p>
    </div>
    
    <div class="profile-section">
        <h2>Truths About Me</h2>
        <p><?= nl2br($profile['truths']) ?></p>
    </div>

    <div class="profile-section">
        <h2>Contact Details</h2>
        <p><strong>Phone:</strong> <?= $profile['phone'] ?></p>
        <p><strong>Email:</strong> <?= $profile['email'] ?></p>
    </div>
    
    <?php if (!empty($profile['facebook_id']) || !empty($profile['instagram_id'])): ?>
    <div class="profile-section">
        <h2>Social Media</h2>
        <?php if (!empty($profile['facebook_id'])): ?>
            <p><strong>Facebook:</strong> <?= $profile['facebook_id'] ?></p>
        <?php endif; ?>
        <?php if (!empty($profile['instagram_id'])): ?>
            <p><strong>Instagram:</strong> <?= $profile['instagram_id'] ?></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>


<div class="back-bottom">
    <form method="post" action="index1.php">
        <button type="submit">Back to Profiles</button>
    </form>
</div>
<script src="all.js"></script>
</body>
</html>