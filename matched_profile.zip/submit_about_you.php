<?php
session_start();

try {
    $servername = "localhost";
    $username = "root";
    $password = ""; 
    $dbname = "tinder";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die(json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error]));
    }

    if (isset($_SESSION['uname']) && isset($_SESSION['pass'])) {
        $uname = $_SESSION['uname'];
        $pass = $_SESSION['pass'];
    } else {
        die(json_encode(['status' => 'error', 'message' => 'Username and password session not found.']));
    }

    // Check if username exists
    $stmt_check = $conn->prepare("SELECT COUNT(*) FROM account WHERE username = ?");
    $stmt_check->bind_param("s", $uname);
    $stmt_check->execute();
    $stmt_check->bind_result($count);
    $stmt_check->fetch(); 

    if ($count > 0) {
        die(json_encode(['status' => 'error', 'message' => 'Username already taken.']));
    }
    $stmt_check->close(); 

    // Insert into account table
    $stmt = $conn->prepare("INSERT INTO account (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $uname, $pass);

    if (!$stmt->execute()) {
        die(json_encode(['status' => 'error', 'message' => 'Account creation failed: ' . $stmt->error]));
    }

    $user_id = $conn->insert_id;

    // Get values from the form
    $fullName = $_POST['fullName'];
    $dob = date('Y-m-d', strtotime($_POST['dob']));
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $facebook = $_POST['facebook'];
    $instagram = $_POST['instagram'];
    $bio = $_POST['bio'];
    $hobbies = $_POST['hobbies'];
    $occupation = $_POST['occupation'];
    $education = $_POST['education'];
    $religion = $_POST['religion'];
    $languages = $_POST['languages'];
    $smoking = isset($_POST['smoking']) ? $_POST['smoking'] : "";
    $drinking = isset($_POST['drinking']) ? $_POST['drinking'] : "";
    $pets = $_POST['pets'];
    $lookingFor = $_POST['lookingFor'];
    $favorites = $_POST['favorites'];
    $vacation = $_POST['vacation'];
    $truths = $_POST['truths'];
    $gender = $_SESSION['gender'];
    $location = $_POST['location'];

    // File upload handling
    if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
        $conn->query("DELETE FROM account WHERE id = $user_id");
        die(json_encode(['status' => 'error', 'message' => 'No file uploaded or an upload error occurred.']));
    }
    
    $photo = $_FILES['photo']['name'];  
    $tmp_name = $_FILES['photo']['tmp_name'];  
    $target_directory = "images/";
    $target_file = $target_directory . basename($photo);
    
    if (!file_exists($target_directory)) {
        mkdir($target_directory, 0777, true);
    }
    
    if (!move_uploaded_file($tmp_name, $target_file)) {
        $conn->query("DELETE FROM account WHERE id = $user_id");
        die(json_encode(['status' => 'error', 'message' => 'File could not be moved.']));
    }

    // Age check
    $dobObject = new DateTime($dob);
    $today = new DateTime(); 
    $age = $today->diff($dobObject)->y; 
    if($age < 18) {
        $conn->query("DELETE FROM account WHERE id = $user_id");
        die(json_encode(['status' => 'error', 'message' => 'You are too young to use this app']));
    }

    // Validate phone number
    if (!ctype_digit($phone) || strlen($phone) !== 10) {
        $conn->query("DELETE FROM account WHERE id = $user_id");
        die(json_encode(['status' => 'error', 'message' => 'Phone number must be exactly 10 digits and contain only numbers.']));
    }

    // Insert into about_you
    $stmt2 = $conn->prepare("INSERT INTO about_you 
        (full_name, dob, location, email, phone, facebook_id, instagram_id, bio, hobbies, occupation, education, religion, languages, smoking, drinking, pets, looking_for, favorites, vacation, truths, gender, user_id, profile_photo) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt2->bind_param("sssssssssssssssssssssss", 
        $fullName, $dob, $location, $email, $phone, $facebook, $instagram, $bio,
        $hobbies, $occupation, $education, $religion, $languages, $smoking,
        $drinking, $pets, $lookingFor, $favorites, $vacation, $truths,
        $gender, $user_id, $photo);
    
    if ($stmt2->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Account successfully created!']);
    } else {
        $conn->query("DELETE FROM account WHERE id = $user_id");
        echo json_encode(['status' => 'error', 'message' => 'Unable to create account: ' . $stmt2->error]);
    }

    $stmt2->close();
    $stmt->close();
} catch (Exception $e) {
    if (isset($user_id)) {
        $conn->query("DELETE FROM account WHERE id = $user_id");
    }
    die(json_encode(['status' => 'error', 'message' => 'Error: ' . $e->getMessage()]));
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?>