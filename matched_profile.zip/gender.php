<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gender = $_POST['gender'];


    $_SESSION['gender'] = $gender;


    if ($gender == 'male') {
        header("Location: aMquestions.html");
    } else {
        header("Location: aFquestions.html");
    }
    exit();
}
?>
