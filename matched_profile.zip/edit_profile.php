<?php
session_start();
include("connect.php");  // Include the database connection

if (!isset($_SESSION['user_id'])) {
    echo "<script>
            alert('Error: Please log in first.');
            window.location.href='login.php';
          </script>";
    exit();
}

$userId = $_SESSION['user_id'];

// Fetch current user data
$query = mysqli_prepare($con, "SELECT * FROM about_you WHERE user_id = ?");
mysqli_stmt_bind_param($query, "i", $userId);
mysqli_stmt_execute($query);
$result = mysqli_stmt_get_result($query);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    echo "<script>
            alert('Error: Profile not found.');
            window.location.href='menu.html';
          </script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch form data
    $fullName = $_POST['fullName'];
    $dob = date('Y-m-d', strtotime($_POST['dob']));
    $location = $_POST['location'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $facebook = $_POST['facebook'];
    $instagram = $_POST['instagram'];
    $bio = $_POST['bio'];
    $hobbies = $_POST['hobbies'];
    $occupation = $_POST['occupation'];
    $education = $_POST['education'];
    $religion = $_POST['religion'];
    $languages = $_POST['languages'];
    $smoking = isset($_POST['smoking']) ? $_POST['smoking'] : "";
    $lookingFor = $_POST['lookingFor'];
    $favorites = $_POST['favorites'];
    $vacation = $_POST['vacation'];
    $truths = $_POST['truths'];
    $gender = $_POST['gender'];

    // Check if a new photo is uploaded
    if (!empty($_FILES['photo']['name'])) {
        $photo = $_FILES['photo']['name'];  
        $tmp_name = $_FILES['photo']['tmp_name'];  
        $target_directory = "images/";
        $target_file = $target_directory . basename($photo);

        // Create directory if not exists
        if (!file_exists($target_directory)) {
            mkdir($target_directory, 0777, true);
        }

        // Move uploaded file
        if (move_uploaded_file($tmp_name, $target_file)) {
            $profilePhoto = $photo; // New photo
        } else {
            echo "<script>
                    alert('Error: File upload failed.');
                    window.location.href='edit_profile.php';
                  </script>";
            exit();
        }
    } else {
        // Keep the existing photo
        $profilePhoto = $row['profile_photo'];
    }

    $stmt = mysqli_prepare($con, "UPDATE about_you SET 
    full_name = ?, dob = ?, location = ?, email = ?, phone = ?, facebook_id = ?, 
    instagram_id = ?, bio = ?, hobbies = ?, occupation = ?, education = ?, 
    religion = ?, languages = ?, smoking = ?, looking_for = ?, 
    favorites = ?, vacation = ?, truths = ?, profile_photo = ?, gender = ? 
    WHERE user_id = ?");

mysqli_stmt_bind_param($stmt, "ssssssssssssssssssssi", 
    $fullName, $dob, $location, $email, $phone, $facebook, 
    $instagram, $bio, $hobbies, $occupation, $education, 
    $religion, $languages, $smoking, $lookingFor, 
    $favorites, $vacation, $truths, $profilePhoto, $gender, $userId);


    if (mysqli_stmt_execute($stmt)) {
        echo "<script>
                alert('Profile updated successfully!');
                window.location.href='aprofile.php';
              </script>";
    } else {
        echo "<script>
                alert('Error updating profile.');
                window.location.href='edit_profile.php';
              </script>";
    }

    mysqli_stmt_close($stmt);
}

mysqli_close($con);
?>
