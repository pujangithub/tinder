<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];
include("connect.php");

// Get user's gender
$genderQuery = mysqli_query($con, "SELECT gender FROM about_you WHERE user_id = $userId");
$genderRow = mysqli_fetch_assoc($genderQuery);
$gender = $genderRow['gender'];
$oppositeGender = ($gender == 'male') ? 'female' : 'male';

// Get profiles
$profilesQuery = mysqli_query($con, "SELECT * FROM about_you WHERE gender = '$oppositeGender' AND user_id NOT IN (SELECT blocked_user_id FROM blocks WHERE user_id = $userId)");
$profiles = mysqli_fetch_all($profilesQuery, MYSQLI_ASSOC);

// Reset profile index if it's out of bounds or if we're coming from a block action
if (!isset($_SESSION['profile_index']) || $_SESSION['profile_index'] >= count($profiles)) {
    $_SESSION['profile_index'] = 0;
}

$profileIndex = $_SESSION['profile_index'];
$currentProfile = $profiles[$profileIndex] ?? null;

// Check if current profile is liked
$isLiked = false;
if ($currentProfile) {
    $checkLike = $con->prepare("SELECT id FROM likes WHERE user_id = ? AND liked_user_id = ?");
    $checkLike->bind_param("ii", $userId, $currentProfile['user_id']);
    $checkLike->execute();
    $isLiked = $checkLike->get_result()->num_rows > 0;
    $checkLike->close();
}

// Handle navigation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['next'])) {
        $profileIndex = ($profileIndex + 1) % count($profiles);
    } elseif (isset($_POST['previous'])) {
        $profileIndex = ($profileIndex - 1 + count($profiles)) % count($profiles);
    }
    $_SESSION['profile_index'] = $profileIndex;
    header("Location: index1.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dating App</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="all.css">
    <link rel="stylesheet" href="all1.css">
    <style> 
    .pageTitle{
        color:transparent;
    }
     .heart {
        position: absolute;
        bottom: 63px; 
        right: 15px; 
        cursor: pointer;
    } </style>
</head>
<body>
<video autoplay loop muted plays-inline class="background-video" src="fluffyBall.mp4"></video>

<div class="nav">
    <a href="index1.php"><img src="logoo.png" alt="Logo"></a>
    <a href="about_us.php" class="block1">About us</a>
    <a href="contact_us.php" class="block1">Contact us</a>
    <a href="aprofile.php" class="block1">Profile</a>
</div>

<div class="main">
    <?php if ($currentProfile): ?>
        <div class="image-container">
            <div class="image-card">
                <img src="images/<?= $currentProfile['profile_photo'] ?>" alt="Profile">
                <div class="three-dots">
                    &#x22EE;    
                </div>
                <div class="delete-update-options">
                    <a href="block.php?block_user_id=<?= $currentProfile['user_id'] ?>">Block</a>
                </div>
            </div>
        </div>
        <div class="pageTitle">
    <a href="index1.php"><h1>.    .</h1></a>
    </div>
        <div class="details">
            <h2>Name: <?= $currentProfile['full_name'] ?></h2>
            <h2>Age: <?php
                $dob = new DateTime($currentProfile['dob']);
                echo $dob->diff(new DateTime())->y;
            ?></h2>
            <h2>Location: <?= $currentProfile['location'] ?></h2>
            <h2>Looking for: <?= $currentProfile['looking_for'] ?></h2>
            <a href="more_details.php?user_id=<?= $currentProfile['user_id'] ?>"><h4>More details</h4></a>
        </div>

        <div class="details2">
            <form method="post">
                <button type="submit" name="next">Next</button>
            </form>
        </div>

        <div class="details3">
            <form method="post">
                <button type="submit" name="previous">Previous</button>
            </form>
        </div>

        <button class="heart <?= $isLiked ? 'clicked' : '' ?>" 
                type="button" 
                data-user-id="<?= $currentProfile['user_id'] ?>"></button>
    <?php else: ?>
        <h2>No more profiles to show</h2>
    <?php endif; ?>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        const dots = document.querySelector(".three-dots");
        const options = document.querySelector(".delete-update-options");

        dots.addEventListener("click", function() {
            options.classList.toggle("show-options");
        });
    });
</script>

<script>
    $(document).ready(function() {
        $('.heart').click(function() {
            const button = $(this);
            const userId = <?= $userId ?>;
            const likedUserId = button.data('user-id');

            $.ajax({
                url: 'like.php',
                type: 'POST',
                data: { liked_user_id: likedUserId },
                success: function(response) {
                    response = response.trim();
                    if (response === 'liked') {
                        button.addClass('clicked');
                        alert('Profile liked!');
                    } else if (response === 'unliked') {
                        button.removeClass('clicked');
                        alert('Profile unliked!');
                    } else {
                        alert('Error: ' + response);
                    }
                },
                error: function(xhr) {
                    alert('Error: ' + xhr.statusText);
                }
            });
        });
    });
</script>

</body>
</html>