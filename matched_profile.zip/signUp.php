<?php
session_start();

try {
    include('connect.php');
    $con = new mysqli($servername, $username, $password, $dbname);
    
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $uname = $_POST['uname'];
        $pass = $_POST['pass'];

        // Check if username and password are empty
        if (empty($uname) || empty($pass)) {
            echo "<script>
                    alert('Username and password are required!');
                    window.location.href='signup.html';
                </script>";
            exit();
        }

        // Escape user input to prevent SQL injection
        $uname = $con->real_escape_string($uname);
        $pass = $con->real_escape_string($pass);

        // Optimized Query to Check If Username Exists
        $query = "SELECT username FROM account WHERE username = '$uname'";
        $check = mysqli_query($con, $query);

        if (mysqli_num_rows($check) > 0) {
            echo "<script>
                    alert('Username already exists!');
                    window.location.href='signup.html';
                </script>";
            exit();
        } else {
            // Store username and password in session
            $_SESSION['uname'] = $uname;
            $_SESSION['pass'] = $pass;

            echo "<script>
                    window.location.href='gender.html';
                </script>";
            exit();
        }
    }
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
} finally {
    if (isset($con)) {
        $con->close();
    }
}
?>
